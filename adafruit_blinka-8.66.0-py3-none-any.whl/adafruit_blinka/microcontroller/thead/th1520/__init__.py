# SPDX-FileCopyrightText: 2024 Chris Brown
#
# SPDX-License-Identifier: MIT
"""Definition for the T-Head TH1520 chip"""
