# SPDX-FileCopyrightText: 2024 Vladimir Shtarev, Jetbrains Research
#
# SPDX-License-Identifier: MIT
"""Definition for the StarFive JH7110 chip"""
